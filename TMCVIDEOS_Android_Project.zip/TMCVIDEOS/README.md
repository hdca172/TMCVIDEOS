# TMCVIDEOS para Android

Proyecto inicial de una aplicación Android con interfaz oscura y reproductor Media3.

## Funciones incluidas
- Reproducir archivos de video seleccionados desde el teléfono.
- Reproducir enlaces directos HTTP/HTTPS a archivos multimedia compatibles (por ejemplo MP4, HLS si el servidor lo permite).
- Controles de reproducción de Media3.

## Limitaciones de esta primera versión
- No incluye catálogo de películas o series ni aloja contenido.
- No reproduce automáticamente páginas de YouTube, TikTok, Facebook o servicios con DRM; para eso se requieren integraciones y permisos específicos.
- Usa únicamente videos propios o contenido que tengas derecho a reproducir.

## Compilación
El workflow de GitHub Actions compila `app-debug.apk` al subir cambios a `main` o al ejecutarlo manualmente desde Actions.

En GitHub: Actions > Compilar TMCVIDEOS APK > Run workflow. Cuando termine correctamente, descarga el artefacto `TMCVIDEOS-APK` y extrae `app-debug.apk`.

Requisitos: Android Studio/Gradle en la nube mediante GitHub Actions; no hace falta una computadora local.
